# File Location: tools/terminal.py
import subprocess

class TerminalTool:
    @staticmethod
    def run_command(command: str):
        """
        Executes PowerShell scripts. 
        Critical for 'Advanced' tasks like clearing cache or checking IP.
        """
        try:
            # Captures standard output and error stream
            result = subprocess.check_output(
                ["powershell", "-Command", command], 
                stderr=subprocess.STDOUT, 
                shell=True
            )
            output = result.decode('utf-8')
            return f"Command executed. Output: {output[:100]}..." # Keep response short
        except subprocess.CalledProcessError as e:
            return f"Terminal Error: {e.output.decode('utf-8')}"