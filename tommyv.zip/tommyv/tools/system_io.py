# File Location: tools/system_io.py
import os
import subprocess
import screen_brightness_control as sbc
from pycaw.pycaw import AudioUtilities, IAudioEndpointVolume
from comtypes import CLSCTX_ALL
from ctypes import cast, POINTER

class SystemTools:
    @staticmethod
    def adjust_volume(level: int):
        """Sets the system volume (0-100)."""
        devices = AudioUtilities.GetSpeakers()
        interface = devices.Activate(IAudioEndpointVolume._iid_, CLSCTX_ALL, None)
        volume = cast(interface, POINTER(IAudioEndpointVolume))
        volume.SetMasterVolumeLevelScalar(level / 100, None)
        return f"System volume set to {level}%"

    @staticmethod
    def adjust_brightness(level: int):
        """Sets the screen brightness (0-100)."""
        sbc.set_brightness(level)
        return f"Screen brightness set to {level}%"

    @staticmethod
    def launch_app(app_name: str):
        """Opens a Windows application."""
        try:
            # Using 'start' allows Windows to find the app path automatically
            subprocess.Popen(f"start {app_name}", shell=True)
            return f"Opening {app_name} now."
        except Exception as e:
            return f"Failed to open {app_name}: {str(e)}"

    @staticmethod
    def power_command(action: str):
        """Triggers system power states: shutdown, restart, lock."""
        action = action.lower()
        if "lock" in action:
            os.system("rundll32.exe user32.dll,LockWorkStation")
            return "Locking the workstation."
        elif "shutdown" in action:
            os.system("shutdown /s /t 1")
            return "Initiating system shutdown."
        return f"Power command '{action}' not recognized."