# File Location: tools/smart_controller.py
import pyautogui
import time

class SmartController:
    @staticmethod
    def click_at(x: int, y: int, clicks: int = 1):
        """Moves to estimated screen coordinates and clicks."""
        pyautogui.moveTo(x, y, duration=0.5)
        pyautogui.click(clicks=clicks)
        return f"Clicked at {x}, {y}."

    @staticmethod
    def type_text(text: str):
        pyautogui.write(text, interval=0.05)
        pyautogui.press('enter')
        return f"Typed: {text}"

    @staticmethod
    def press_key(key: str):
        pyautogui.press(key)
        return f"Pressed {key}."