# File Location: tools/local_engine.py
import webbrowser
import os
import pyautogui
import time
from tools.system_io import SystemTools

class LocalEngine:
    def __init__(self):
        # 20+ SMART LOCAL SHORTCUTS
        self.commands = {
            # --- Browser & Web ---
            "google": lambda q: webbrowser.open(f"https://www.google.com/search?q={q}"),
            "youtube": lambda q: webbrowser.open(f"https://www.youtube.com/results?search_query={q}"),
            "gmail": lambda: webbrowser.open("https://mail.google.com"),
            "maps": lambda q: webbrowser.open(f"https://www.google.com/maps/search/{q}"),
            "new tab": lambda: pyautogui.hotkey('ctrl', 't'),
            "close tab": lambda: pyautogui.hotkey('ctrl', 'w'),
            
            # --- System Control ---
            "open chrome": lambda: SystemTools.launch_app("chrome"),
            "open notepad": lambda: SystemTools.launch_app("notepad"),
            "open settings": lambda: pyautogui.hotkey('win', 'i'),
            "open explorer": lambda: SystemTools.launch_app("explorer"),
            "open task manager": lambda: pyautogui.hotkey('ctrl', 'shift', 'esc'),
            "minimize all": lambda: pyautogui.hotkey('win', 'd'),
            "maximize": lambda: pyautogui.hotkey('win', 'up'),
            "lock": lambda: os.system("rundll32.exe user32.dll,LockWorkStation"),
            
            # --- Audio & Media ---
            "mute": lambda: pyautogui.press("volumemute"),
            "volume up": lambda: pyautogui.press("volumeup"),
            "volume down": lambda: pyautogui.press("volumedown"),
            "play": lambda: pyautogui.press("playpause"),
            "pause": lambda: pyautogui.press("playpause"),
            "next": lambda: pyautogui.press("nexttrack"),
            
            # --- Tools ---
            "screenshot": lambda: pyautogui.hotkey('win', 'printscreen'),
            "calculator": lambda: SystemTools.launch_app("calc"),
            "terminal": lambda: SystemTools.launch_app("powershell"),
            "undo": lambda: pyautogui.hotkey('ctrl', 'z'),
            "redo": lambda: pyautogui.hotkey('ctrl', 'y')
        }

    def try_execute(self, text):
        text = text.lower().strip()
        for trigger, action in self.commands.items():
            if text.startswith(trigger):
                query = text.replace(trigger, "").strip()
                print(f"⚡ Local Shortcut: {trigger}")
                if query:
                    try: action(query)
                    except TypeError: action() # Handle if action doesn't take args
                else:
                    action()
                return True
        return False