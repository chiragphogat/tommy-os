# File Location: main.py
import speech_recognition as sr
import os
import sys
from google import genai
from google.genai import types

from core.speaker import say
from core.vision import TommyVision
from tools.system_io import SystemTools
from tools.terminal import TerminalTool
from tools.smart_controller import SmartController
from tools.local_engine import LocalEngine 

# ================= CONFIGURATION =================
GEMINI_API_KEY = "AIzaSyBzQKaX381KZNSEEB9y_-tuZQOzz-9LWLs"
client = genai.Client(api_key=GEMINI_API_KEY)
local_brain = LocalEngine() 

tools_list = [
    SystemTools.adjust_volume, SystemTools.adjust_brightness,
    SystemTools.launch_app, TerminalTool.run_command,
    SmartController.click_at, SmartController.type_text, SmartController.press_key
]

def process_command(text):
    command = text.lower().strip()
    
    # 1. Ignore short noise (Prevents Quota Drain)
    if len(command.split()) < 2: 
        return

    print(f"\n🎤 Heard: '{command}'")

    # 2. Check Local Database (0% Quota usage)
    if local_brain.try_execute(command):
        return 

    # 3. Gemini Brain (Only for complex or vision tasks)
    # We only trigger this if the command is long or contains specific 'intent' words
    intent_words = ["click", "search", "why", "how", "what", "screen", "error", "this"]
    if any(word in command for word in intent_words):
        print("🧠 Complex intent detected. Using Gemini...")
        
        contents = [command]
        if any(w in command for w in ["screen", "this", "look", "click"]):
            path = TommyVision.take_screenshot()
            with open(path, "rb") as f:
                contents.append(types.Part.from_bytes(data=f.read(), mime_type="image/png"))

        try:
            response = client.models.generate_content(
                model="gemini-2.0-flash",
                contents=contents,
                config=types.GenerateContentConfig(
                    tools=tools_list,
                    system_instruction="You are TommyV. Execute tools briefly."
                )
            )
            # Execute tool logic here (omitted for brevity, keep your existing loop)
            # ...
        except Exception as e:
            print(f"❌ API Busy: {e}")
            say("Brain is cooling down.")
    else:
        print("☁️ Ignoring ambient conversation to save quota.")

def main():
    r = sr.Recognizer()
    # Adjust sensitivity so it doesn't hear the hum of your laptop fan
    r.energy_threshold = 4000 
    
    with sr.Microphone() as source:
        print("\n🔍 Calibrating Sensors (Silence please)...")
        r.adjust_for_ambient_noise(source, duration=2)
    
    say("Tommy is active and protecting your quota.")
    while True:
        try:
            with sr.Microphone() as source:
                print("👂 Monitoring...        ", end="\r")
                audio = r.listen(source, phrase_time_limit=4)
                text = r.recognize_google(audio)
                process_command(text)
        except: continue

if __name__ == "__main__":
    main()