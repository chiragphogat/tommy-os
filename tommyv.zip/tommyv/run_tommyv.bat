:: File Location: tommyv/run_tommyv.bat
@echo off
title TommyV OS Bootloader
echo [SYSTEM] TommyV is initializing...

:: Get the current folder path automatically
set PROJECT_DIR=%~dp0
cd /d %PROJECT_DIR%

:: Check if Python is installed
python --version >nul 2>&1
if %errorlevel% neq 0 (
    echo [ERROR] Python not found. Please install Python to run TommyV.
    pause
    exit
)

:: Launch the main engine
echo [SYSTEM] Starting Brain and Sensors...
python main.py

pause