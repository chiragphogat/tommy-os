# File Location: core/vision.py
import pyautogui
import os

class TommyVision:
    @staticmethod
    def take_screenshot():
        """Captures screen for button detection and system monitoring."""
        path = "screen_capture.png"
        screenshot = pyautogui.screenshot()
        screenshot.save(path)
        return path

    @staticmethod
    def cleanup():
        if os.path.exists("screen_capture.png"):
            os.remove("screen_capture.png")