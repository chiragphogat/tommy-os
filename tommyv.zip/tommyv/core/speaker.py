# File Location: core/speaker.py
import edge_tts
import asyncio
import pygame
import os

class TommySpeaker:
    def __init__(self):
        self.voice = "en-GB-ThomasNeural" 
        if not pygame.mixer.get_init():
            pygame.mixer.init()

    async def _generate_and_play(self, text):
        output_file = "response.mp3"
        communicate = edge_tts.Communicate(text, self.voice)
        await communicate.save(output_file)
        pygame.mixer.music.load(output_file)
        pygame.mixer.music.play()
        while pygame.mixer.music.get_busy():
            await asyncio.sleep(0.1)
        pygame.mixer.music.unload()
        if os.path.exists(output_file):
            try: os.remove(output_file)
            except: pass

def say(text):
    speaker = TommySpeaker()
    try:
        asyncio.run(speaker._generate_and_play(text))
    except Exception as e:
        print(f"Voice Error: {e}")